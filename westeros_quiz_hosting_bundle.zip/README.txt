Westeros House Sorting Quiz (Hosted)

Fastest hosting (no code) — Netlify Drop:
1) Go to https://app.netlify.com/drop
2) Drag-and-drop the ZIP (or just index.html) onto the page
3) Netlify will instantly give you a shareable URL.

GitHub Pages (free):
1) Create a new GitHub repo (public is simplest).
2) Upload index.html to the repo root.
3) Repo Settings → Pages → Deploy from branch → main → /(root)
4) Your quiz will be live at the Pages URL.

Cloudflare Pages / Vercel:
- Create a new “static site” and upload index.html as the output.
